-- decompiled by Sentinel (took 184.616µs)
return {
	{
		{ 1546851900, "14/01/2019" }, 
		{ "!laserEyes command (Donor)" }, 
		{ "!thanos command (Donor)" }, 
		{ "!headSnap command (Donor)" }, 
		{ "!fart command (Donor)" }, 
		{ "!warp command (Donor)" }
	}, 
	{
		{ 1546851900, "13/01/2019" }, 
		{ "Redesigned UI" }
	}
}
