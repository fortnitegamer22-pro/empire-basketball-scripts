-- decompiled by Sentinel (took 213.586µs)
require(script.Parent:WaitForChild("PlayerModule"))
