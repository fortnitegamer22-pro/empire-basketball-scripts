-- decompiled by Sentinel (took 167.164µs)
local _ = _G.HDAdminMain
return {}
