-- decompiled by Sentinel (took 265.21µs)
return {
	["MessageTypeDefault"] = "Message", 
	["MessageTypeSystem"] = "System", 
	["MessageTypeMeCommand"] = "MeCommand", 
	["MessageTypeWelcome"] = "Welcome", 
	["MessageTypeSetCore"] = "SetCore", 
	["MessageTypeWhisper"] = "Whisper", 
	["MajorVersion"] = 0, 
	["MinorVersion"] = 8, 
	["BuildVersion"] = "2018.05.16", 
	["VeryLowPriority"] = -5, 
	["LowPriority"] = 0, 
	["StandardPriority"] = 10, 
	["HighPriority"] = 20, 
	["VeryHighPriority"] = 25, 
	["WhisperChannelPrefix"] = "To "
}
