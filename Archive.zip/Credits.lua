-- decompiled by Sentinel (took 455.86µs)
return {
	{
		{ 5, "The Team" }, 
		{
			"ForeverHD", 
			{ "CEO", "Core programming and UI" }
		}, 
		{
			"1waffle1", 
			{ "Lead", "Project and team overview" }
		}, 
		{
			"H_mzah", 
			{ "Web Specialist", "Web service development" }
		}, 
		{
			"Inctus", 
			{ "Scripter", "Command development" }
		}, 
		{
			"OptimisticSide", 
			{ "Scripter", "Command development" }
		}, 
		{
			"Arbeiters", 
			{ "Scripter", "Command development" }
		}, 
		{
			"dantheprogram", 
			{ "Scripter", "Command development" }
		}, 
		{
			"Naperin", 
			{ "Modeler" }
		}, 
		{
			"Gamez_Champ", 
			{ "Tester" }
		}, 
		{
			"HelpBuddyDuck", 
			{ "Tester" }
		}
	}, 
	{
		{ 5, "Contributors" }, 
		{
			"Alvin_Blox", 
			{ "HD Admin Tutorials | AlvinBlox YouTube" }
		}, 
		{
			"GigsD4X", 
			{ "F3X Building Tools" }
		}, 
		{
			"ZapSplat", 
			{ "Sound Effects" }
		}, 
		{
			"stravant", 
			{ "LuaMinify" }
		}
	}, 
	{
		{ 5, "Command Contributions" }
	}
}
