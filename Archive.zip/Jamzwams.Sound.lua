-- decompiled by Sentinel (took 475.061µs)
print("Hello world!")
