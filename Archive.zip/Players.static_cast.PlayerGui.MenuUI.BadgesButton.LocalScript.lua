-- decompiled by Sentinel (took 257.774µs)
script.Parent.TextButton.MouseButton1Click:Connect(function() end)
script.Parent.Parent.Badges.Close.MouseButton1Click:Connect(function() end)
